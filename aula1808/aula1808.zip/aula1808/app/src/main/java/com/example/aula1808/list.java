package com.example.aula1808;

public class list<T> {
}
